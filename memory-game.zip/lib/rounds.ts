import type { LucideIcon } from "lucide-react"
import {
  Apple,
  Banana,
  Cherry,
  Grape,
  Carrot,
  Fish,
  Dog,
  Cat,
  Bird,
  Rabbit,
  Car,
  Bike,
  Plane,
  Ship,
  Train,
  Bus,
  Truck,
  Rocket,
  Sun,
  Moon,
  Cloud,
  Star,
  Snowflake,
  TreePine,
  Flower2,
  Mountain,
  Flame,
  Droplets,
  Music,
  Guitar,
  Hammer,
  Wrench,
  Scissors,
  Ruler,
  Pizza,
  Coffee,
  Cake,
  IceCreamCone,
  Umbrella,
  Anchor,
  Leaf,
  Shirt,
  Watch,
  Glasses,
  Crown,
} from "lucide-react"

export type SortItem = {
  id: string
  label: string
  icon: LucideIcon
  /** index of the correct category (0 = left bin, 1 = right bin) */
  correct: 0 | 1
}

export type Round = {
  id: number
  prompt: string
  categories: [string, string]
  items: SortItem[]
}

export const ROUNDS: Round[] = [
  {
    id: 1,
    prompt: "Sort each picture into the right group.",
    categories: ["Animals", "Vehicles"],
    items: [
      { id: "dog", label: "Dog", icon: Dog, correct: 0 },
      { id: "car", label: "Car", icon: Car, correct: 1 },
      { id: "cat", label: "Cat", icon: Cat, correct: 0 },
      { id: "plane", label: "Plane", icon: Plane, correct: 1 },
      { id: "bird", label: "Bird", icon: Bird, correct: 0 },
      { id: "bus", label: "Bus", icon: Bus, correct: 1 },
    ],
  },
  {
    id: 2,
    prompt: "Which are fruits and which are vehicles?",
    categories: ["Fruits", "Vehicles"],
    items: [
      { id: "apple", label: "Apple", icon: Apple, correct: 0 },
      { id: "train", label: "Train", icon: Train, correct: 1 },
      { id: "banana", label: "Banana", icon: Banana, correct: 0 },
      { id: "truck", label: "Truck", icon: Truck, correct: 1 },
      { id: "grape", label: "Grapes", icon: Grape, correct: 0 },
      { id: "rocket", label: "Rocket", icon: Rocket, correct: 1 },
    ],
  },
  {
    id: 3,
    prompt: "Sky above or ground below?",
    categories: ["Sky", "Ground"],
    items: [
      { id: "sun", label: "Sun", icon: Sun, correct: 0 },
      { id: "tree", label: "Tree", icon: TreePine, correct: 1 },
      { id: "cloud", label: "Cloud", icon: Cloud, correct: 0 },
      { id: "flower", label: "Flower", icon: Flower2, correct: 1 },
      { id: "moon", label: "Moon", icon: Moon, correct: 0 },
      { id: "mountain", label: "Mountain", icon: Mountain, correct: 1 },
    ],
  },
  {
    id: 4,
    prompt: "Make music or fix things?",
    categories: ["Music", "Tools"],
    items: [
      { id: "guitar", label: "Guitar", icon: Guitar, correct: 0 },
      { id: "hammer", label: "Hammer", icon: Hammer, correct: 1 },
      { id: "music", label: "Notes", icon: Music, correct: 0 },
      { id: "wrench", label: "Wrench", icon: Wrench, correct: 1 },
      { id: "scissors", label: "Scissors", icon: Scissors, correct: 1 },
      { id: "ruler", label: "Ruler", icon: Ruler, correct: 1 },
    ],
  },
  {
    id: 5,
    prompt: "Hot things or cold things?",
    categories: ["Hot", "Cold"],
    items: [
      { id: "flame", label: "Fire", icon: Flame, correct: 0 },
      { id: "snow", label: "Snow", icon: Snowflake, correct: 1 },
      { id: "coffee", label: "Coffee", icon: Coffee, correct: 0 },
      { id: "icecream", label: "Ice Cream", icon: IceCreamCone, correct: 1 },
      { id: "sun2", label: "Sun", icon: Sun, correct: 0 },
      { id: "droplet", label: "Water", icon: Droplets, correct: 1 },
    ],
  },
  {
    id: 6,
    prompt: "Land animals or water animals?",
    categories: ["Land", "Water"],
    items: [
      { id: "rabbit", label: "Rabbit", icon: Rabbit, correct: 0 },
      { id: "fish", label: "Fish", icon: Fish, correct: 1 },
      { id: "dog2", label: "Dog", icon: Dog, correct: 0 },
      { id: "ship", label: "Boat", icon: Ship, correct: 1 },
      { id: "cat2", label: "Cat", icon: Cat, correct: 0 },
      { id: "anchor", label: "Anchor", icon: Anchor, correct: 1 },
    ],
  },
  {
    id: 7,
    prompt: "Food or drinks & treats?",
    categories: ["Food", "Treats"],
    items: [
      { id: "pizza", label: "Pizza", icon: Pizza, correct: 0 },
      { id: "cake", label: "Cake", icon: Cake, correct: 1 },
      { id: "carrot", label: "Carrot", icon: Carrot, correct: 0 },
      { id: "icecream2", label: "Ice Cream", icon: IceCreamCone, correct: 1 },
      { id: "cherry", label: "Cherry", icon: Cherry, correct: 0 },
      { id: "coffee2", label: "Coffee", icon: Coffee, correct: 1 },
    ],
  },
  {
    id: 8,
    prompt: "Things to wear or things in nature?",
    categories: ["Wearable", "Nature"],
    items: [
      { id: "shirt", label: "Shirt", icon: Shirt, correct: 0 },
      { id: "leaf", label: "Leaf", icon: Leaf, correct: 1 },
      { id: "watch", label: "Watch", icon: Watch, correct: 0 },
      { id: "flower2", label: "Flower", icon: Flower2, correct: 1 },
      { id: "glasses", label: "Glasses", icon: Glasses, correct: 0 },
      { id: "tree2", label: "Tree", icon: TreePine, correct: 1 },
    ],
  },
  {
    id: 9,
    prompt: "Fly through the air or float on water?",
    categories: ["Air", "Water"],
    items: [
      { id: "plane2", label: "Plane", icon: Plane, correct: 0 },
      { id: "ship2", label: "Ship", icon: Ship, correct: 1 },
      { id: "bird2", label: "Bird", icon: Bird, correct: 0 },
      { id: "umbrella", label: "Umbrella", icon: Umbrella, correct: 1 },
      { id: "rocket2", label: "Rocket", icon: Rocket, correct: 0 },
      { id: "fish2", label: "Fish", icon: Fish, correct: 1 },
    ],
  },
  {
    id: 10,
    prompt: "Final round! Special or everyday?",
    categories: ["Special", "Everyday"],
    items: [
      { id: "crown", label: "Crown", icon: Crown, correct: 0 },
      { id: "bike", label: "Bike", icon: Bike, correct: 1 },
      { id: "star", label: "Star", icon: Star, correct: 0 },
      { id: "coffee3", label: "Coffee", icon: Coffee, correct: 1 },
      { id: "rocket3", label: "Rocket", icon: Rocket, correct: 0 },
      { id: "shirt2", label: "Shirt", icon: Shirt, correct: 1 },
    ],
  },
]

export const TOTAL_ROUNDS = ROUNDS.length
