"use client"

import { Button } from "@/components/ui/button"
import { Trophy, RotateCcw, Sparkles } from "lucide-react"

type ResultScreenProps = {
  score: number
  best: number
  maxScore: number
  onRestart: () => void
}

export function ResultScreen({ score, best, maxScore, onRestart }: ResultScreenProps) {
  const pct = Math.round((score / maxScore) * 100)
  const isNewBest = score >= best && score > 0

  const message =
    pct === 100
      ? "Perfect sort! Flawless victory."
      : pct >= 70
        ? "Great sorting skills!"
        : pct >= 40
          ? "Nice work — keep practicing!"
          : "Good try! Give it another go."

  return (
    <div className="mx-auto w-full max-w-md">
      <div className="flex flex-col items-center gap-5 rounded-3xl border bg-card p-8 text-center shadow-sm">
        <span className="flex size-16 items-center justify-center rounded-2xl bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400">
          <Trophy className="size-8" />
        </span>

        <div>
          <h2 className="text-2xl font-bold">Game Complete</h2>
          <p className="mt-1 text-muted-foreground">{message}</p>
        </div>

        {isNewBest && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-1 text-sm font-semibold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400">
            <Sparkles className="size-4" />
            New best score!
          </span>
        )}

        <div className="flex w-full items-stretch gap-3">
          <div className="flex-1 rounded-2xl border bg-background p-4">
            <p className="text-3xl font-bold tabular-nums text-primary">{score}</p>
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              of {maxScore} points
            </p>
          </div>
          <div className="flex-1 rounded-2xl border bg-background p-4">
            <p className="text-3xl font-bold tabular-nums">{best}</p>
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Best score
            </p>
          </div>
        </div>

        <div className="h-2.5 w-full overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-primary transition-all duration-700"
            style={{ width: `${pct}%` }}
          />
        </div>

        <Button size="lg" onClick={onRestart} className="w-full gap-2">
          <RotateCcw className="size-4" />
          Play Again
        </Button>
      </div>
    </div>
  )
}
