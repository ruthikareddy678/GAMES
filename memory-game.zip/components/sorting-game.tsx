"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import { ROUNDS, TOTAL_ROUNDS, type Round } from "@/lib/rounds"
import { Scoreboard } from "@/components/scoreboard"
import { ItemCard } from "@/components/item-card"
import { CategoryBin } from "@/components/category-bin"
import { ResultScreen } from "@/components/result-screen"
import { Button } from "@/components/ui/button"
import { RotateCcw, Check, ArrowRight } from "lucide-react"

const BEST_KEY = "picture-sorting-best-v1"

type Phase = "playing" | "checked" | "finished"
/** itemId -> bin index it was placed in, or null if still in the tray */
type Placement = Record<string, 0 | 1 | null>

function emptyPlacement(round: Round): Placement {
  return round.items.reduce<Placement>((acc, item) => {
    acc[item.id] = null
    return acc
  }, {})
}

export function SortingGame() {
  const [roundIndex, setRoundIndex] = useState(0)
  const [score, setScore] = useState(0)
  const [best, setBest] = useState(0)
  const [phase, setPhase] = useState<Phase>("playing")
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [placement, setPlacement] = useState<Placement>(() => emptyPlacement(ROUNDS[0]))

  const round = ROUNDS[roundIndex]

  useEffect(() => {
    const stored = Number(window.localStorage.getItem(BEST_KEY) ?? "0")
    if (!Number.isNaN(stored)) setBest(stored)
  }, [])

  const allPlaced = useMemo(
    () => round.items.every((item) => placement[item.id] !== null),
    [round, placement],
  )

  const trayItems = round.items.filter((item) => placement[item.id] === null)

  const placeSelected = useCallback(
    (bin: 0 | 1) => {
      if (phase !== "playing" || !selectedId) return
      setPlacement((prev) => ({ ...prev, [selectedId]: bin }))
      setSelectedId(null)
    },
    [phase, selectedId],
  )

  const returnToTray = useCallback(
    (itemId: string) => {
      if (phase !== "playing") return
      setPlacement((prev) => ({ ...prev, [itemId]: null }))
      setSelectedId(null)
    },
    [phase],
  )

  const handleCheck = useCallback(() => {
    if (!allPlaced) return
    const correctCount = round.items.filter(
      (item) => placement[item.id] === item.correct,
    ).length
    setScore((s) => s + correctCount)
    setPhase("checked")
  }, [allPlaced, round, placement])

  const handleNext = useCallback(() => {
    if (roundIndex + 1 >= TOTAL_ROUNDS) {
      setBest((prevBest) => {
        const nextBest = Math.max(prevBest, score)
        window.localStorage.setItem(BEST_KEY, String(nextBest))
        return nextBest
      })
      setPhase("finished")
      return
    }
    const next = roundIndex + 1
    setRoundIndex(next)
    setPlacement(emptyPlacement(ROUNDS[next]))
    setSelectedId(null)
    setPhase("playing")
  }, [roundIndex, score])

  const handleRestart = useCallback(() => {
    setRoundIndex(0)
    setScore(0)
    setPlacement(emptyPlacement(ROUNDS[0]))
    setSelectedId(null)
    setPhase("playing")
  }, [])

  const maxScore = TOTAL_ROUNDS * ROUNDS[0].items.length

  if (phase === "finished") {
    return (
      <ResultScreen
        score={score}
        best={best}
        maxScore={maxScore}
        onRestart={handleRestart}
      />
    )
  }

  const binState = (bin: 0 | 1) =>
    round.items
      .filter((item) => placement[item.id] === bin)
      .map((item) => ({
        item,
        status:
          phase === "checked"
            ? item.correct === bin
              ? ("correct" as const)
              : ("wrong" as const)
            : ("neutral" as const),
      }))

  return (
    <div className="mx-auto flex w-full max-w-4xl flex-col gap-6">
      <Scoreboard
        score={score}
        best={best}
        round={roundIndex + 1}
        totalRounds={TOTAL_ROUNDS}
      />

      <div className="rounded-3xl border bg-card p-5 shadow-sm sm:p-7">
        <p className="text-center text-lg font-medium text-pretty sm:text-xl">
          {round.prompt}
        </p>
        {phase === "playing" && (
          <p className="mt-1 text-center text-sm text-muted-foreground">
            {selectedId
              ? "Now tap the group where it belongs."
              : "Tap a picture, then tap a group."}
          </p>
        )}

        {/* Bins */}
        <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <CategoryBin
            label={round.categories[0]}
            active={selectedId !== null && phase === "playing"}
            accent="left"
            onSelect={() => placeSelected(0)}
            contents={binState(0)}
            onReturn={returnToTray}
            interactive={phase === "playing"}
          />
          <CategoryBin
            label={round.categories[1]}
            active={selectedId !== null && phase === "playing"}
            accent="right"
            onSelect={() => placeSelected(1)}
            contents={binState(1)}
            onReturn={returnToTray}
            interactive={phase === "playing"}
          />
        </div>

        {/* Tray */}
        <div className="mt-5 rounded-2xl border border-dashed bg-muted/40 p-4">
          <p className="mb-3 text-center text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Pictures to sort
          </p>
          {trayItems.length === 0 ? (
            <p className="py-4 text-center text-sm text-muted-foreground">
              All pictures placed. {phase === "playing" ? "Ready to check!" : ""}
            </p>
          ) : (
            <div className="flex flex-wrap justify-center gap-3">
              {trayItems.map((item) => (
                <ItemCard
                  key={item.id}
                  item={item}
                  selected={selectedId === item.id}
                  onClick={() =>
                    setSelectedId((prev) => (prev === item.id ? null : item.id))
                  }
                />
              ))}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          {phase === "playing" ? (
            <Button size="lg" onClick={handleCheck} disabled={!allPlaced} className="gap-2">
              <Check className="size-5" />
              Check Answers
            </Button>
          ) : (
            <Button size="lg" onClick={handleNext} className="gap-2">
              {roundIndex + 1 >= TOTAL_ROUNDS ? "See Results" : "Next Round"}
              <ArrowRight className="size-5" />
            </Button>
          )}
          <Button size="lg" variant="ghost" onClick={handleRestart} className="gap-2">
            <RotateCcw className="size-4" />
            Restart
          </Button>
        </div>

        {phase === "checked" && (
          <p className="mt-4 text-center text-sm font-medium">
            You got{" "}
            <span className="text-primary">
              {round.items.filter((i) => placement[i.id] === i.correct).length}
            </span>{" "}
            of {round.items.length} correct this round.
          </p>
        )}
      </div>
    </div>
  )
}
