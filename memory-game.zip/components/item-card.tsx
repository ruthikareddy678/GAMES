"use client"

import { cn } from "@/lib/utils"
import type { SortItem } from "@/lib/rounds"

type ItemCardProps = {
  item: SortItem
  selected?: boolean
  onClick?: (e?: React.MouseEvent) => void
  status?: "neutral" | "correct" | "wrong"
  compact?: boolean
}

export function ItemCard({
  item,
  selected = false,
  onClick,
  status = "neutral",
  compact = false,
}: ItemCardProps) {
  const Icon = item.icon
  const clickable = typeof onClick === "function"

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!clickable}
      aria-pressed={selected}
      className={cn(
        "group flex flex-col items-center gap-1.5 rounded-2xl border-2 bg-background text-center transition-all",
        compact ? "w-20 px-2 py-2.5" : "w-24 px-3 py-3.5",
        clickable && "cursor-pointer hover:-translate-y-0.5 hover:shadow-md",
        !clickable && "cursor-default",
        selected
          ? "border-primary ring-2 ring-primary/30 -translate-y-0.5 shadow-md"
          : "border-border",
        status === "correct" &&
          "border-emerald-500 bg-emerald-50 dark:bg-emerald-500/10",
        status === "wrong" && "border-red-500 bg-red-50 dark:bg-red-500/10",
      )}
    >
      <Icon
        className={cn(
          "size-8 transition-colors",
          status === "correct"
            ? "text-emerald-600 dark:text-emerald-400"
            : status === "wrong"
              ? "text-red-600 dark:text-red-400"
              : selected
                ? "text-primary"
                : "text-foreground/80",
        )}
        aria-hidden="true"
      />
      <span className="text-xs font-medium leading-none">{item.label}</span>
    </button>
  )
}
