"use client"

import { cn } from "@/lib/utils"
import { ItemCard } from "@/components/item-card"
import type { SortItem } from "@/lib/rounds"

type BinContent = {
  item: SortItem
  status: "neutral" | "correct" | "wrong"
}

type CategoryBinProps = {
  label: string
  accent: "left" | "right"
  active: boolean
  interactive: boolean
  contents: BinContent[]
  onSelect: () => void
  onReturn: (itemId: string) => void
}

export function CategoryBin({
  label,
  accent,
  active,
  interactive,
  contents,
  onSelect,
  onReturn,
}: CategoryBinProps) {
  const accentClasses =
    accent === "left"
      ? "from-sky-50 to-sky-100/40 dark:from-sky-500/10 dark:to-sky-500/5"
      : "from-violet-50 to-violet-100/40 dark:from-violet-500/10 dark:to-violet-500/5"

  return (
    <div
      role={active ? "button" : undefined}
      tabIndex={active ? 0 : undefined}
      aria-label={active ? `Place picture in ${label}` : undefined}
      onClick={active ? onSelect : undefined}
      onKeyDown={
        active
          ? (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault()
                onSelect()
              }
            }
          : undefined
      }
      className={cn(
        "flex min-h-40 w-full flex-col rounded-2xl border-2 bg-gradient-to-b p-4 text-left transition-all",
        accentClasses,
        active
          ? "cursor-pointer border-primary border-dashed ring-2 ring-primary/20 hover:ring-primary/40"
          : "border-border/60",
      )}
    >
      <span className="mb-3 self-center rounded-full border bg-background/70 px-3 py-1 text-sm font-bold">
        {label}
      </span>
      {contents.length === 0 ? (
        <span className="flex flex-1 items-center justify-center text-sm text-muted-foreground">
          {active ? "Tap to place here" : "Empty"}
        </span>
      ) : (
        <div className="flex flex-wrap justify-center gap-2">
          {contents.map(({ item, status }) => (
            <ItemCard
              key={item.id}
              item={item}
              status={status}
              compact
              onClick={
                interactive && !active
                  ? (e) => {
                      e?.stopPropagation()
                      onReturn(item.id)
                    }
                  : active
                    ? onSelect
                    : undefined
              }
            />
          ))}
        </div>
      )}
    </div>
  )
}
