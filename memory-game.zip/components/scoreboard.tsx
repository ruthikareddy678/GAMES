import { Star, Target, Trophy } from "lucide-react"

type ScoreboardProps = {
  score: number
  best: number
  round: number
  totalRounds: number
}

function Stat({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode
  label: string
  value: string
  tone: string
}) {
  return (
    <div className="flex flex-1 items-center gap-3 rounded-2xl border bg-card px-4 py-3 shadow-sm">
      <span
        className={`flex size-9 shrink-0 items-center justify-center rounded-xl ${tone}`}
        aria-hidden="true"
      >
        {icon}
      </span>
      <div className="leading-tight">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="text-lg font-bold tabular-nums">{value}</p>
      </div>
    </div>
  )
}

export function Scoreboard({ score, best, round, totalRounds }: ScoreboardProps) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row">
      <Stat
        icon={<Star className="size-5" />}
        label="Score"
        value={String(score)}
        tone="bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400"
      />
      <Stat
        icon={<Target className="size-5" />}
        label="Round"
        value={`${round} / ${totalRounds}`}
        tone="bg-sky-100 text-sky-600 dark:bg-sky-500/15 dark:text-sky-400"
      />
      <Stat
        icon={<Trophy className="size-5" />}
        label="Best"
        value={String(best)}
        tone="bg-violet-100 text-violet-600 dark:bg-violet-500/15 dark:text-violet-400"
      />
    </div>
  )
}
